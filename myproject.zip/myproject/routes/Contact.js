var express = require('express');
var router = express.Router();
var MongoClient = require('mongodb').MongoClient;
var url = "mongodb+srv://mongodb+srv://yashjoshi21123:<aPNjlyRhOJyDJqDN>@cluster0.4hveapd.mongodb.net/?retryWrites=true&w=majority"

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('Contact');
});

router.post('/', function(req, res, next) {
  //res.send('the form is submitted');
  //res.render('contact',{message: 'Message sent!'});

  var fullname = req.body.senderName;
  var email = req.body.email;
  var sub = req.body.subject;
  var msg = req.body.message1;

  MongoClient.connect(url, function(err, db){
    if(err) throw err;

    var database = db.db("mydatabase");
    var userObj = {fName:fullname, email:email, sub:sub, msg:msg};
    database.collections("studentinfo").insertOne(userObj, function(err, res){
      if(err) throw err;
      console.log("User was successfully connected");
      db.close();
    })
  })
  
  res.render('Contact');
});

module.exports = router;
